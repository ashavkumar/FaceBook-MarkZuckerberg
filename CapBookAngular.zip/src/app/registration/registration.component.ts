import { Component, OnInit } from '@angular/core';
import { CapbookService } from 'src/app/services/capbook.service';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Profile } from '../registration/profile';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  error:string;
  message:string;
  _firstName:string='';
  _lastName:string='';
  _dateOfBirth:string;
  _gender:string='';
  _emailId:string='';
  _password:string='';
  _confirmPassword:string='';
  _securityQuestion:string='';
  _securityAnswer:string='';
  profile:Profile;

  constructor(private route:ActivatedRoute,private router:Router,private capbookService:CapbookService) { }

  
  get firstName(): string{
    return this._firstName;
  }

  set firstName(value: string){
    this._firstName = value;
  }

  get lastName(): string{
    return this._lastName;
  }

  set lastName(value: string){
    this._lastName = value;
  }
  get dateOfBirth(): string{
    return this._dateOfBirth;
  }

  set dateOfBirth(value: string){
    this._dateOfBirth = value;
  }

  get gender(): string{
    return this._gender;
  }

  set gender(value: string){
    this._gender = value;
  }
  
  get emailId(): string{
    return this._emailId;
  }

  set emailId(value: string){
    this._emailId = value;
  }

  get password(): string{
    return this._password;
  }

  set password(value: string){
    this._password = value;
  }
  get confirmPassword(): string{
    return this._password;
  }

  set confirmPassword(value: string){
    this._password = value;
  }

  get securityQuestion(): string{
    return this._securityQuestion;
  }

  set securityQuestion(value: string){
    this._securityQuestion = value;
  }

  get securityAnswer(): string{
    return this._securityAnswer;
  }

  set securityAnswer(value: string){
    this._securityAnswer = value;
  }
  
  ngOnInit() {
  }

  onSubmitClick(){
    const profile:any={
      firstName:this.firstName,
      lastName:this.lastName,
      dateOfBirth:this.dateOfBirth,
      gender:this.gender,
      emailId:this.emailId,
      password:this.password,
      securityQuestion:this.securityQuestion,
      securityAnswer:this.securityAnswer
    }
    this.capbookService.registerUser(profile).subscribe(
      profile=>{
        console.log(JSON.stringify(profile));
        this.profile=profile;
        localStorage.setItem("currentProfile",JSON.stringify(profile));
        this.message='You have successfully registered!!';
        console.log(this.message);
      },
      error=>{
        this.error='Oops!!!Email Already Used.Try with another Email';
      }
    );
 
  }

}
