import { Component, OnInit } from '@angular/core';
import { CapbookService } from 'src/app/services/capbook.service';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Profile } from '../registration/profile';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {

  error:string;
  message:string;
  _userBio:string='';
  _currentCity:string='';
  _workPlace:string;
  _highestEducation:string='';
  _relationshipStatus:string='';
  profile:Profile;

  currentProfile:Profile;

  constructor(private route:ActivatedRoute,private router:Router,private capbookService:CapbookService) {
    this.currentProfile=  JSON.parse(localStorage.getItem("currentProfile"));
   }


  get userBio(): string{
    return this._userBio;
  }

  set userBio(value: string){
    this._userBio = value;
  }

  get currentCity(): string{
    return this._currentCity;
  }

  set currentCity(value: string){
    this._currentCity = value;
  }
  get workPlace(): string{
    return this._workPlace;
  }

  set workPlace(value: string){
    this._workPlace = value;
  }

  get highestEducation(): string{
    return this._highestEducation;
  }

  set highestEducation(value: string){
    this._highestEducation = value;
  }
  
  get relationshipStatus(): string{
    return this._relationshipStatus;
  }

  set relationshipStatus(value: string){
    this._relationshipStatus = value;
  }

  
  ngOnInit() {
  }

  onSaveChangesClick(){
    const profile:any={
      emailId:this.currentProfile.emailId,
      userBio:this.userBio,
      currentCity:this.currentCity,
      workPlace:this.workPlace,
      highestEducation:this.highestEducation,
      relationshipStatus:this.relationshipStatus
      
    }
    this.capbookService.editProfile(profile).subscribe(
      profile=>{
        console.log(JSON.stringify(profile));
        this.profile=profile;
        localStorage.setItem("currentProfile",JSON.stringify(profile));
        this.message='Changes saved successfully!!';
      },
      error=>{
        this.error=error;
      }
    );
 
  }


}
