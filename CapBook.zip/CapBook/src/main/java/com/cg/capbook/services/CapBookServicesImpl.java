package com.cg.capbook.services;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.capbook.beans.Profile;
import com.cg.capbook.beans.User;
import com.cg.capbook.daoservices.ProfileDAO;
import com.cg.capbook.daoservices.UserDAO;
import com.cg.capbook.exceptions.EmailAlreadyUsedException;
import com.cg.capbook.exceptions.InvalidEmailIdException;
import com.cg.capbook.exceptions.InvalidPasswordException;
public class CapBookServicesImpl implements CapBookServices{
	@Autowired
	private UserDAO userDAO;
	@Autowired
	private ProfileDAO profileDAO;
	@Override
	public void registerUser(User user) throws EmailAlreadyUsedException {
		if(userDAO.findById(user.getEmailId()).isPresent())
			throw new EmailAlreadyUsedException();
		userDAO.save(user);
	}
	@Override
	public Profile loginUser(User user) throws InvalidEmailIdException, InvalidPasswordException {
		User user1=userDAO.findById(user.getEmailId()).orElseThrow(()->new InvalidEmailIdException());
		if(!user1.getPassword().equals(user.getPassword()))
			throw new InvalidPasswordException();
		return user1.getProfile();
	}
	@Override
	public Profile editProfile(Profile profile) {
		ZoneId zonedId = ZoneId.of( "America/Montreal" );
		LocalDate today = LocalDate.now( zonedId );
		profile.setDateOfJoining(today.toString());
		profileDAO.save(profile);
		return profile;
	}
}
