import { Component, OnInit } from '@angular/core';
import { CapbookService } from 'src/app/services/capbook.service';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Profile } from '../registration/profile';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  error:string;
  message:string='';
  _currentPassword:string='';
  _newPassword:string='';
  
  profile:Profile;
  currentProfile:Profile;

  constructor(private route:ActivatedRoute,private router:Router,private capbookService:CapbookService) {
    this.currentProfile=  JSON.parse(localStorage.getItem("currentProfile"));
   }
   get currentPassword(): string{
    return this._currentPassword;
  }

  set currentPassword(value: string){
    this._currentPassword = value;
  }

  get newPassword(): string{
    return this._newPassword;
  }

  set newPassword(value: string){
    this._newPassword = value;
  }

  ngOnInit() {
  }

  onSaveChangesClick(){
    const profile:any={
      emailId:this.currentProfile.emailId,
      password:this.newPassword
    }

    this.capbookService.changePassword(profile).subscribe(
      profile=>{
        console.log(JSON.stringify(profile));
        this.profile=profile;
        localStorage.setItem("currentProfile",JSON.stringify(profile));
        this.message='Password changed successfully';
      },
      error=>{
        this.error=error;
      }
    );

}
}
