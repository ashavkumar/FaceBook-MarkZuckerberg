package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Post {
	@Id
	private int postId;
	private String postName;
	private int noOfPostLikes;
}
