export interface Post {
    postContent:string;
	emailId:string;
}