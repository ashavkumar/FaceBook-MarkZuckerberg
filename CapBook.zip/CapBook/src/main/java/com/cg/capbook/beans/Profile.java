package com.cg.capbook.beans;
import java.awt.Image;
import java.util.Map;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
@Entity
public class Profile {
	@Id
	private int profileId;
	private String firstName;
	private String lastName;
	private String dateOfBirth;
	private String gender;
	private String userBio;
	//private Image profilePic;
	private String relationshipStatus;
	private String dateOfJoining;
	private String workPlace;
	@ManyToMany
	private Map<Integer, Page> pages;
	@OneToMany
	private Map<Integer, Post> posts;
	@ManyToMany
	private Map<Integer,Friend> friends;
	@Embedded
	private Address address;
	@Embedded
	private Education education;
	public Profile() {
		super();
	}
	public Profile(int profileId, String firstName, String lastName, String dateOfBirth, String gender, String userBio,
			Image profilePic, String relationshipStatus, String dateOfJoining, String workPlace,
			Map<Integer, Page> pages, Map<Integer, Post> posts, Map<Integer, Friend> friends, Address address,
			Education education) {
		super();
		this.profileId = profileId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.userBio = userBio;
		//this.profilePic = profilePic;
		this.relationshipStatus = relationshipStatus;
		this.dateOfJoining = dateOfJoining;
		this.workPlace = workPlace;
		this.pages = pages;
		this.posts = posts;
		this.friends = friends;
		this.address = address;
		this.education = education;
	}
	public int getProfileId() {
		return profileId;
	}
	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getUserBio() {
		return userBio;
	}
	public void setUserBio(String userBio) {
		this.userBio = userBio;
	}
	/*public Image getProfilePic() {
		return profilePic;
	}
	public void setProfilePic(Image profilePic) {
		this.profilePic = profilePic;
	}*/
	public String getRelationshipStatus() {
		return relationshipStatus;
	}
	public void setRelationshipStatus(String relationshipStatus) {
		this.relationshipStatus = relationshipStatus;
	}
	public String getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public String getWorkPlace() {
		return workPlace;
	}
	public void setWorkPlace(String workPlace) {
		this.workPlace = workPlace;
	}
	public Map<Integer, Page> getPages() {
		return pages;
	}
	public void setPages(Map<Integer, Page> pages) {
		this.pages = pages;
	}
	public Map<Integer, Post> getPosts() {
		return posts;
	}
	public void setPosts(Map<Integer, Post> posts) {
		this.posts = posts;
	}
	public Map<Integer, Friend> getFriends() {
		return friends;
	}
	public void setFriends(Map<Integer, Friend> friends) {
		this.friends = friends;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Education getEducation() {
		return education;
	}
	public void setEducation(Education education) {
		this.education = education;
	}
}
