package com.cg.capbook.services;
import com.cg.capbook.beans.Profile;
import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.EmailAlreadyUsedException;
import com.cg.capbook.exceptions.InvalidEmailIdException;
import com.cg.capbook.exceptions.InvalidPasswordException;
public interface CapBookServices {
	void registerUser(User user) throws EmailAlreadyUsedException;
	Profile loginUser(User user) throws InvalidEmailIdException,InvalidPasswordException;
	Profile editProfile(Profile profile);
}
