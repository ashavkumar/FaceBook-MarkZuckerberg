export interface Profile {
    firstName:string;
    lastName:string;
    dateOfBirth:string;
    gender:string;
    emailId:string;
    password:string;
    homeTown:string;
	dateOfJoining:string;
	userBio:string;
	currentCity:string;
	workPlace:string;
	highestEducation:string;
    relationshipStatus:string;
}
