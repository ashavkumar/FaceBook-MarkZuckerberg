package com.cg.capbook.beans;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
@Entity
public class Comment {
	@Id
	private int commentId;
	private String comment;
	private String commentPerson;
	@ManyToOne
	@MapKey
	@JoinColumn(name="postId")
	private Post posts;
	public Comment() {
		super();
	}
	public Comment(int commentId, String comment, String commentPerson) {
		super();
		this.commentId = commentId;
		this.comment = comment;
		this.commentPerson = commentPerson;
	}
	public int getCommentId() {
		return commentId;
	}
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getCommentPerson() {
		return commentPerson;
	}
	public void setCommentPerson(String commentPerson) {
		this.commentPerson = commentPerson;
	}
	
}
