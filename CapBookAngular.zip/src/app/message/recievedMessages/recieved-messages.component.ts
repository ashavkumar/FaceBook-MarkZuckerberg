import { Component, OnInit } from '@angular/core';
import { Profile } from 'src/app/registration/profile';
import { CapbookService } from 'src/app/services/capbook.service';
import { Message } from '../message';

@Component({
  selector: 'app-recieved-messages',
  templateUrl: './recieved-messages.component.html',
  styleUrls: ['./recieved-messages.component.css']
})
export class RecievedMessagesComponent implements OnInit {

  profile:Profile
  messageList:Message[]
  constructor(private capBookService:CapbookService) { }

  ngOnInit() {
    this.profile=JSON.parse(localStorage.getItem("currentProfile"))
    this.capBookService.getRecievedMessages(this.profile.emailId).subscribe(
      messageList=>{
        this.messageList=messageList;
        console.log(messageList)
      },
      error=>{
        console.log(error)
      }
    );

  }

}
