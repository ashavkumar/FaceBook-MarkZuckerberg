import { Component, OnInit } from '@angular/core';
import { CapbookService } from 'src/app/services/capbook.service';
import { Post } from '../post';

@Component({
  selector: 'app-add-post',
  templateUrl: './add-post.component.html',
  styleUrls: ['./add-post.component.css']
})
export class AddPostComponent implements OnInit {

  _postMessage:string;
  post:Post
  constructor(private capbookService:CapbookService) { }

  ngOnInit() {
  }

  set postMessage(value: string){
    this._postMessage = value;
  }

  get postMessage(): string{
    return this._postMessage;
  }

  
  onSubmitClick(){
    const post:any={
      postContent:this.postMessage
         
    }
    this.capbookService.createPost(post).subscribe(
      post=>{
        console.log(JSON.stringify(post));
        this.post=post;
        console.log("in success");
        console.log(this.post);
      },
      error=>{
        console.log("error")
      }
    );
    location.reload();
  }

  
}