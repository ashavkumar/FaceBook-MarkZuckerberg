package com.cg.capbook.beans;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Page {
	@Id
	private int pageId;
	private int noOfPageLikes;
	@OneToMany
	private Map<Integer, Post> posts;
}
